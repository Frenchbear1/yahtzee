// lib/game.ts
var categories = [
  { id: "ones", name: "Aces", hint: "Add all ones", face: 1 },
  { id: "twos", name: "Twos", hint: "Add all twos", face: 2 },
  { id: "threes", name: "Threes", hint: "Add all threes", face: 3 },
  { id: "fours", name: "Fours", hint: "Add all fours", face: 4 },
  { id: "fives", name: "Fives", hint: "Add all fives", face: 5 },
  { id: "sixes", name: "Sixes", hint: "Add all sixes", face: 6 },
  { id: "kind3", name: "3 of a kind", hint: "Total of all five dice" },
  { id: "kind4", name: "4 of a kind", hint: "Total of all five dice" },
  { id: "house", name: "Full house", hint: "Three + two matching", fixed: 25 },
  { id: "small", name: "Small straight", hint: "Four in a row", fixed: 30 },
  { id: "large", name: "Large straight", hint: "Five in a row", fixed: 40 },
  { id: "yahtzee", name: "Yahtzee", hint: "Five of a kind", fixed: 50 },
  { id: "chance", name: "Chance", hint: "Total of all five dice" }
];
function totals(scores = {}, bonus = 0) {
  const upper = categories.slice(0, 6).reduce((a, c) => a + (scores[c.id] ?? 0), 0);
  const upperBonus = upper >= 63 ? 35 : 0;
  const lower = categories.slice(6).reduce((a, c) => a + (scores[c.id] ?? 0), 0) + bonus * 100;
  const filled = categories.filter((c) => scores[c.id] !== null && scores[c.id] !== void 0).length;
  return { upper, upperBonus, upperTotal: upper + upperBonus, lower, total: upper + upperBonus + lower, filled, remaining: 13 - filled };
}
function validScore(id2, value) {
  const c = categories.find((c2) => c2.id === id2);
  if (!c) return false;
  if (value === null) return true;
  if (typeof value !== "number" || !Number.isInteger(value)) return false;
  if ("face" in c) return value >= 0 && value <= c.face * 5 && value % c.face === 0;
  if ("fixed" in c) return value === 0 || value === c.fixed;
  return value === 0 || value >= 5 && value <= 30;
}

// lib/server.ts
var APIError = class extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
};
var fail = (message, status = 400) => {
  throw new APIError(message, status);
};
var id = () => crypto.randomUUID();
var code = () => Array.from(crypto.getRandomValues(new Uint8Array(4)), (n) => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[n % 32]).join("");
var clean = (s, fallback) => typeof s === "string" && s.trim() ? s.trim().slice(0, 32) : fallback;
async function shortenCode(db, room) {
  if (!room || room.code.length <= 4) return;
  for (let i = 0; i < 5; i++) {
    const next = code();
    try {
      const changed = await db.prepare("UPDATE rooms SET code=? WHERE id=? AND NOT EXISTS (SELECT 1 FROM rooms WHERE code=?)").bind(next, room.id, next).run();
      if (changed.meta?.changes) {
        room.code = next;
        return;
      }
    } catch {
    }
  }
}
async function handleGame(request, db, mode = "online") {
  const json = (d, status = 200) => Response.json(d, { status, headers: { "Cache-Control": "no-store" } });
  try {
    const token = request.headers.get("x-player-token") || "";
    if (!/^[a-zA-Z0-9-]{32,100}$/.test(token)) fail("Your player profile needs to reconnect. Refresh and try again.", 401);
    if (Number(request.headers.get("content-length")) > 12e3) fail("Request too large.", 413);
    const raw = await request.text();
    if (raw.length > 12e3) fail("Request too large.", 413);
    const b = JSON.parse(raw);
    if (!b || typeof b !== "object") fail("Invalid request.");
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token))), (b2) => b2.toString(16).padStart(2, "0")).join("");
    const seenAt = Date.now();
    let me = await db.prepare("SELECT id,name,current_room FROM players WHERE token=?").bind(hash).first();
    if (!me) {
      if (b.action !== "bootstrap") fail("Reconnect your player profile.", 401);
      const pid = id(), rid = id(), gid = id(), now = Date.now();
      await db.batch([db.prepare("INSERT INTO players (id,token,name,current_room,last_seen) VALUES (?,?,?,?,?)").bind(pid, hash, "You", rid, now), db.prepare("INSERT INTO rooms (id,name,code,host_id,created_at) VALUES (?,?,?,?,?)").bind(rid, "My table", code(), pid, now), db.prepare("INSERT INTO members (room_id,player_id) VALUES (?,?)").bind(rid, pid), db.prepare("INSERT INTO games (id,room_id,started_at) VALUES (?,?,?)").bind(gid, rid, now), db.prepare("INSERT INTO sheets (game_id,player_id) VALUES (?,?)").bind(gid, pid)]);
      me = { id: pid, name: "You", current_room: rid };
    }
    await db.prepare("UPDATE players SET last_seen=? WHERE id=?").bind(seenAt, me.id).run();
    const snapshot = async () => {
      const room = await db.prepare("SELECT id,name,code,host_id FROM rooms WHERE id=?").bind(me.current_room).first();
      if (room?.host_id === me.id) await shortenCode(db, room);
      const roomRows = await db.prepare("SELECT r.id,r.name,r.code,r.host_id FROM rooms r JOIN members m ON r.id=m.room_id WHERE m.player_id=? ORDER BY r.created_at DESC").bind(me.id).all();
      const playerRows = await db.prepare("SELECT p.id,p.name,p.current_room,p.last_seen FROM players p JOIN members m ON m.player_id=p.id WHERE m.room_id=? ORDER BY p.name").bind(me.current_room).all();
      const gs = await db.prepare("SELECT * FROM games WHERE room_id=? ORDER BY started_at DESC").bind(me.current_room).all();
      const ss = await db.prepare("SELECT s.*,p.name FROM sheets s JOIN players p ON p.id=s.player_id WHERE s.game_id IN (SELECT id FROM games WHERE room_id=? ORDER BY started_at DESC)").bind(me.current_room).all();
      const history = gs.results.map((g) => ({ ...g, sheets: ss.results.filter((s) => s.game_id === g.id).map((s) => ({ ...s, scores: JSON.parse(s.scores) })) }));
      return { me: { id: me.id, name: me.name }, room, rooms: roomRows.results, players: playerRows.results.map((p) => ({ id: p.id, name: p.name, active: p.current_room === me.current_room && seenAt - p.last_seen < 15e3 })), game: history[0], history, mode };
    };
    if (b.action === "rename") {
      const name = clean(b.name, "You");
      await db.prepare("UPDATE players SET name=? WHERE id=?").bind(name, me.id).run();
      me.name = name;
    } else if (b.action === "create-room") {
      const rid = id(), gid = id(), now = Date.now();
      await db.batch([db.prepare("INSERT INTO rooms (id,name,code,host_id,created_at) VALUES (?,?,?,?,?)").bind(rid, clean(b.name, "Family table"), code(), me.id, now), db.prepare("INSERT INTO members (room_id,player_id) VALUES (?,?)").bind(rid, me.id), db.prepare("INSERT INTO games (id,room_id,started_at) VALUES (?,?,?)").bind(gid, rid, now), db.prepare("INSERT INTO sheets (game_id,player_id) VALUES (?,?)").bind(gid, me.id), db.prepare("UPDATE players SET current_room=? WHERE id=?").bind(rid, me.id)]);
      me.current_room = rid;
    } else if (b.action === "join-room" || b.action === "switch-room") {
      const room = b.action === "join-room" ? await db.prepare("SELECT * FROM rooms WHERE code=?").bind(String(b.code || "").replace(/[^a-z0-9]/gi, "").toUpperCase()).first() : await db.prepare("SELECT r.* FROM rooms r JOIN members m ON r.id=m.room_id WHERE r.id=? AND m.player_id=?").bind(String(b.roomId || ""), me.id).first();
      if (!room) fail("That table wasn\u2019t found. Check the eight-letter code.");
      const g = await db.prepare("SELECT * FROM games WHERE room_id=? ORDER BY started_at DESC LIMIT 1").bind(room.id).first();
      const statements = [db.prepare("INSERT OR IGNORE INTO members (room_id,player_id) VALUES (?,?)").bind(room.id, me.id), db.prepare("UPDATE players SET current_room=? WHERE id=?").bind(room.id, me.id)];
      if (g && !g.ended_at) statements.push(db.prepare("INSERT OR IGNORE INTO sheets (game_id,player_id) SELECT ?,? WHERE EXISTS (SELECT 1 FROM games WHERE id=? AND ended_at IS NULL)").bind(g.id, me.id, g.id));
      await db.batch(statements);
      me.current_room = room.id;
    } else if (b.action === "score" || b.action === "bonus") {
      const s = await db.prepare("SELECT s.*,g.room_id FROM sheets s JOIN games g ON g.id=s.game_id WHERE s.game_id=? AND s.player_id=? AND g.room_id=?").bind(String(b.gameId || ""), me.id, me.current_room).first();
      if (!s) fail("This score sheet is not available.", 404);
      const latest = await db.prepare("SELECT id FROM games WHERE room_id=? ORDER BY started_at DESC LIMIT 1").bind(me.current_room).first();
      if (latest.id !== s.game_id) fail("This game has been saved to history. Open the current game.", 409);
      if (b.revision !== s.revision) fail("This score changed on another screen. Your sheet has been refreshed; try again.", 409);
      const scores = JSON.parse(s.scores);
      let bonus = s.bonus;
      if (b.action === "score") {
        if (!validScore(b.category, b.value)) fail("Choose a valid score for this category.");
        scores[b.category] = b.value;
        if (b.category === "yahtzee") {
          if (b.value !== 50) bonus = 0;
          else if (b.restoreBonus !== void 0) {
            if (!Number.isInteger(b.restoreBonus) || b.restoreBonus < 0 || b.restoreBonus > 12) fail("That Yahtzee bonus cannot be restored.");
            bonus = b.restoreBonus;
          }
        }
      } else {
        if (!Number.isInteger(b.bonus) || b.bonus < 0 || b.bonus > 12) fail("Choose between 0 and 12 extra Yahtzees.");
        if (b.bonus > 0 && scores.yahtzee !== 50) fail("Score your first Yahtzee as 50 before adding a bonus.");
        bonus = b.bonus;
      }
      const complete = totals(scores, bonus).filled === 13 ? Date.now() : null;
      const updated = await db.prepare("UPDATE sheets SET scores=?,bonus=?,revision=revision+1,completed_at=? WHERE game_id=? AND player_id=? AND revision=?").bind(JSON.stringify(scores), bonus, complete, s.game_id, me.id, b.revision).run();
      if (!updated.meta?.changes) fail("Another screen changed this score. Please try again.", 409);
      await db.prepare("UPDATE games SET ended_at=CASE WHEN NOT EXISTS (SELECT 1 FROM sheets WHERE game_id=? AND completed_at IS NULL) THEN COALESCE(ended_at,?) ELSE NULL END WHERE id=?").bind(s.game_id, Date.now(), s.game_id).run();
    } else if (b.action === "new-game") {
      const room = await db.prepare("SELECT * FROM rooms WHERE id=?").bind(me.current_room).first();
      if (room.host_id !== me.id) fail("The table host starts the next game.", 403);
      const g = await db.prepare("SELECT * FROM games WHERE room_id=? ORDER BY started_at DESC LIMIT 1").bind(me.current_room).first();
      if (g.id !== b.gameId) fail("A new game has already started. Your table is refreshed.", 409);
      if (!g.ended_at && !b.confirm) fail("There are unfinished score sheets. Confirm to start a fresh game.");
      const gid = id(), started = Date.now();
      const created = await db.batch([db.prepare("INSERT INTO games (id,room_id,started_at) SELECT ?,?,? WHERE (SELECT id FROM games WHERE room_id=? ORDER BY started_at DESC LIMIT 1)=?").bind(gid, me.current_room, started, me.current_room, g.id), db.prepare("INSERT INTO sheets (game_id,player_id) SELECT ?,m.player_id FROM members m JOIN players p ON p.id=m.player_id WHERE m.room_id=? AND (m.player_id=? OR (p.current_room=? AND p.last_seen>=?)) AND EXISTS (SELECT 1 FROM games WHERE id=?)").bind(gid, me.current_room, me.id, me.current_room, started - 15e3, gid)]);
      if (!created[0].meta?.changes) fail("A new game has already started. Your table is refreshed.", 409);
    } else if (b.action !== "bootstrap" && b.action !== "refresh") {
      fail("Unknown action.");
    }
    const current = await db.prepare("SELECT id FROM games WHERE room_id=? AND ended_at IS NULL ORDER BY started_at DESC LIMIT 1").bind(me.current_room).first();
    if (current) await db.prepare("INSERT OR IGNORE INTO sheets (game_id,player_id) SELECT ?,? WHERE EXISTS (SELECT 1 FROM members WHERE room_id=? AND player_id=?)").bind(current.id, me.id, me.current_room, me.id).run();
    return json(await snapshot());
  } catch (e) {
    if (e instanceof APIError) return json({ error: e.message }, e.status);
    if (e instanceof SyntaxError) return json({ error: "That request could not be read." }, 400);
    console.error("Game request failed", e);
    return json({ error: "Your table is temporarily unavailable. Your unsaved input is still here; please try again." }, 503);
  }
}
export {
  handleGame
};
